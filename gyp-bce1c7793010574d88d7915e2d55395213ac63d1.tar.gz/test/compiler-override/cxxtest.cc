// Copyright (c) 2012 Google Inc. All rights reserved.
// Use of this source code is governed by a BSD-style license that can be
// found in the LICENSE file.

// Deliberate C syntax error as this file should never be passed to
// the actual compiler
#error Should not be passed to a real compiler
