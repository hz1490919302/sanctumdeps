From test2.c
