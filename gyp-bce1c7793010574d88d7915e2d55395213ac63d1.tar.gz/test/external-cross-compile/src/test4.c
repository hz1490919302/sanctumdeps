From test4.c
