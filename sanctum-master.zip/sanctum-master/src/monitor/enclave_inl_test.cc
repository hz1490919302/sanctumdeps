#include "enclave_inl.h"

#include "gtest/gtest.h"

